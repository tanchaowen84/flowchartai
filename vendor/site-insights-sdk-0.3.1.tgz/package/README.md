# @site-insights/sdk

Browser analytics and experiment exposure, portable server HTTP client, typed page/pricing values and optional React bindings. No business database dependency. Never expose a server write key in browser code.

## Shared data and Agent interface (0.3)

`@site-insights/sdk/analytics` is the single interface for all sites. The endpoint is the application root, e.g. `https://myplausible.app/insights` (do not append `/api/v1`). Read keys discover only their granted sites. Write keys are bound to one site/environment; they cannot read analytics.

```ts
import { createAnalyticsClient } from '@site-insights/sdk/analytics';
const reader = createAnalyticsClient({endpoint, siteId, key: readKey});
const discovery = await reader.discover(); // API paths + machine-readable JSON schemas
const catalog = await reader.catalog(); // definitions, observed fields, source coverage
const result = await reader.query({
  kind: 'aggregate', from, to, timezone: 'Asia/Shanghai',
  filters: [{field:'name', op:'eq', value:'option_changed'}],
  group_by: ['attributes.choice'],
  metrics: [{op:'count'}, {op:'distinct', field:'person'}],
});
for await (const row of reader.export({from,to,limit:500})) {
  // Every receipt up to a stable watermark. Do not stop at an empty filtered page.
}
```

Define a version-one manifest deliberately using a write client, then use `ingest({events,entities,links,relations})`. Attribute values are declared scalar types, never unrestricted browser properties. Adding optional fields is compatible; changing an existing field's meaning/type requires a new field. Core trusted events and financial validation cannot be overridden by a manifest. Browser `tracker.event(name, attributes)` works only for declared browser observations; `tracker.track(label)` remains compatible.

An entity is `{type,id,revision,occurred_at,attributes}`; a link is `{event_id,role,entity:{type,id,revision}}`. Revisions and event-role bindings are immutable. Links may be backfilled against existing events without changing their fingerprints. The complete ingestion batch is atomic. Relations connect exact revisions via `{from,relation,to}`. Prefer source revision IDs or immutable event snapshots; never label mutable current settings as historical selections. Do not send prompts, contents, emails or credential material as attributes.

Queries support `aggregate`, `sequence`, `retention`, and `paths`. Sequence and retention use the first qualifying entry per selected person/session/entity within the date range and follow it beyond the range; only mature windows enter conversion denominators. Retention uses rolling 24-hour periods, not calendar-day boundaries. Identity links are deterministic and scoped; they are resolved at query time. Object bindings may be added later, so export watermarks freeze receipts, not subsequent identity/association enrichment. Missing collection and QA classification remain coverage limitations. Monetary fields use micros and must not combine currencies.

The query engine rejects excessive event/byte/group budgets. Narrow the range or use export for larger datasets. Exports allow a range up to 366 days, 200,000 events per snapshot, five active snapshots and 500,000 retained snapshot members per site/environment. Completing an export releases it; call `closeExport(cursor)` when abandoning manual pagination. The async iterator closes unfinished exports in its `finally` block. Export cursors last 24 hours, bind the exact selection and site/environment, and resume until `next_cursor` is null. Server errors are surfaced; the SDK does not invent successful writes or silently retry different payloads. Retry the identical stable event IDs after transient failures.

Polling sources use `INSIGHTS_SOURCES` JSON with `{id,site_id,environment,url,token_env,profiles_url?}`. The HTTPS hostname must equal the registered site domain; redirects are rejected. Tokens stay in server environment variables. A feed returns `{events,cursor,coverage,manifest?,entities?,links?,relations?}` with at most 100 events. Cursor advances only after an atomic ingest; each source has separate status/cursor. The legacy Flowchart environment configuration remains supported. Keep the feed cursor based on durable source receipt order and document reconciliation limits for late commits.

Build in the parent repository with `npm run build:sdk`, then `npm pack ./sdk`. Install the versioned tarball in a site. Imports: `@site-insights/sdk/browser`, `/server`, `/contracts`, `/react`. Browser and server must use the same `siteId`; the server key fixes the environment.

Register an allowlisted capability manifest using `createExperimentClient(...).register(targets)` as a deliberate setup command. This does not create or start experiments. Keep page components, authentication, buyer eligibility and fulfillment in the website adapter. Quote configuration is authoritative only when resolved through the authenticated server client and durably copied to the local checkout.

`sharedCookie: true` lets browser and server share `anonymousCookie(siteId)`; servers should seed that cookie before a first page decision. Never cache personalized HTML across visitors. `ExperimentPage` renders registered React modules from a page assignment; `ExperimentExposure` records actual visibility for a server decision and refuses a changed identity. New components or billing models need an adapter; existing configurations can be varied without another website deployment.

Pass QA mode into server decisions and trusted QA-account classification into quotes. A server-adopted exposure derives its environment from the signed assignment and checks that environment's registered origin; the browser cannot override it. Private decisions/quotes support staging; legacy general browser collection and public text assignment remain production-only. Keep staging origins distinct in the site registry.

Browser custom events use UTF-8 byte-bounded batches. Requests above the keepalive budget are sent without keepalive; an event exceeding 120 KiB is rejected synchronously before entering the queue. Delivery remains an observation, not a business guarantee.
