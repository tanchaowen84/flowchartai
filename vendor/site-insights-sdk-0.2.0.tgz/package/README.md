# @site-insights/sdk

Browser analytics and experiment exposure, portable server HTTP client, typed page/pricing values and optional React bindings. No business database dependency. Never expose a server write key in browser code.

Build in the parent repository with `npm run build:sdk`, then `npm pack ./sdk`. Install the versioned tarball in a site. Imports: `@site-insights/sdk/browser`, `/server`, `/contracts`, `/react`. Browser and server must use the same `siteId`; the server key fixes the environment.

Register an allowlisted capability manifest using `createExperimentClient(...).register(targets)` as a deliberate setup command. This does not create or start experiments. Keep page components, authentication, buyer eligibility and fulfillment in the website adapter. Quote configuration is authoritative only when resolved through the authenticated server client and durably copied to the local checkout.

`sharedCookie: true` lets browser and server share `anonymousCookie(siteId)`; servers should seed that cookie before a first page decision. Never cache personalized HTML across visitors. `ExperimentPage` renders registered React modules from a page assignment; `ExperimentExposure` records actual visibility for a server decision and refuses a changed identity. New components or billing models need an adapter; existing configurations can be varied without another website deployment.
